import 'package:flutter/material.dart';

import '../data/today_api.dart';
import '../models/today_models.dart';
import 'collection_page.dart';
import 'settings_page.dart';
import '../auth/auth_session.dart';
import '../auth/auth_pages.dart';
import 'user_cloud_progress_page.dart';

/// 「我的」一级页面。
/// 资产来自本地 SQLite；等级与成长系统在后续版本接入。
class MyPage extends StatefulWidget {
  const MyPage({
    super.key,
    required this.api,
    required this.auth,
    this.refreshToken = 0,
  });

  final TodayApi api;
  final AuthSession auth;
  final int refreshToken;

  @override
  State<MyPage> createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  TodayData? _data;
  bool _loading = true;
  String? _error;
  int _requestSequence = 0;
  int? _serverWater;
  bool _waterLoading = false;
  String? _waterMessage;

  static const Color _background = Color(0xFFF6F8F5);
  static const Color _forest = Color(0xFF315C48);
  static const Color _muted = Color(0xFF78857B);
  static const Color _border = Color(0xFFE3E9E2);

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant MyPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.api != widget.api ||
        oldWidget.refreshToken != widget.refreshToken) {
      _load();
    }
  }

  Future<void> _load() async {
    final sequence = ++_requestSequence;
    setState(() {
      _loading = true;
      _error = null;
    });

    _loadServerWater(sequence);
    try {
      final result = await widget.api.getToday();
      if (!mounted || sequence != _requestSequence) return;
      setState(() => _data = result);
    } catch (error) {
      if (!mounted || sequence != _requestSequence) return;
      setState(() => _error = error.toString());
    } finally {
      if (mounted && sequence == _requestSequence) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _loadServerWater(int sequence) async {
    final token = widget.auth.token;
    setState(() { _serverWater = null; _waterMessage = null;
      _waterLoading = token != null; });
    if (token == null) {
      if (mounted && sequence == _requestSequence) setState(() {
        _waterMessage = '登录后领取水滴';
      });
      return;
    }
    try {
      final data = await widget.auth.api.getWaterStatus(token);
      if (!mounted || sequence != _requestSequence || widget.auth.token != token) return;
      setState(() => _serverWater = (data['waterBalance'] as num).toInt());
    } catch (_) {
      if (!mounted || sequence != _requestSequence) return;
      setState(() => _waterMessage = '暂无法读取服务器余额');
    } finally {
      if (mounted && sequence == _requestSequence) {
        setState(() => _waterLoading = false);
      }
    }
  }

  Future<void> _openAccount() async {
    if (!widget.auth.isSignedIn) {
      await Navigator.of(context).push<bool>(MaterialPageRoute(
        builder: (_) => LoginPage(session: widget.auth),
      ));
    } else {
      await Navigator.of(context).push<void>(MaterialPageRoute(
        builder: (_) => ProfilePage(session: widget.auth),
      ));
    }
    if (mounted) setState(() {});
  }

  Future<void> _openCloudProgress() async {
    if (!widget.auth.isSignedIn) {
      await _openAccount();
      if (!mounted || !widget.auth.isSignedIn) return;
    }
    await Navigator.of(context).push<void>(MaterialPageRoute(
      builder: (_) => UserCloudProgressPage(api: widget.api, auth: widget.auth),
    ));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final assets = _data?.assets;

    return Scaffold(
      backgroundColor: _background,
      appBar: AppBar(
        title: const Text('我的'),
        backgroundColor: _background,
        actions: [
          IconButton(
            tooltip: '刷新',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
          children: [
            ListenableBuilder(
              listenable: widget.auth,
              builder: (context, _) => InkWell(
                borderRadius: BorderRadius.circular(22),
                onTap: _openAccount,
                child: _profileCard(),
              ),
            ),
            const SizedBox(height: 20),
            _sectionTitle('我的资产', '当前账户余额'),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _assetCard(
                    title: '金币',
                    value: assets == null ? '—' : '${assets.coin}',
                    icon: Icons.monetization_on_outlined,
                    color: const Color(0xFFC29442),
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: _assetCard(
                    title: '经验',
                    value: assets == null ? '—' : '${assets.exp}',
                    icon: Icons.bolt_rounded,
                    color: const Color(0xFF8974B5),
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: _assetCard(
                    title: '水滴',
                    value: _waterLoading ? '…' : (_serverWater?.toString() ?? '—'),
                    icon: Icons.water_drop_outlined,
                    color: const Color(0xFF528DB7),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 7),
            Text(_waterMessage ?? '水滴余额由服务器管理，本地不发放水滴',
              style: const TextStyle(fontSize: 11, color: _muted)),
            if (_loading && _data != null) ...[
              const SizedBox(height: 10),
              const LinearProgressIndicator(minHeight: 2),
            ],
            if (_loading && _data == null) ...[
              const SizedBox(height: 18),
              const Center(child: CircularProgressIndicator()),
            ],
            if (_error != null) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _border),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.cloud_off_outlined, color: _muted),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '资产加载失败：$_error',
                        style: const TextStyle(color: _muted, fontSize: 12),
                      ),
                    ),
                    TextButton(onPressed: _load, child: const Text('重试')),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 20),
            _growthCard(assets?.exp),
            const SizedBox(height: 22),
            _sectionTitle('个人内容', '管理已经获得的内容与进度'),
            const SizedBox(height: 10),
            _menuCard(
              icon: Icons.manage_accounts_outlined,
              iconColor: _forest,
              title: '账号与个人资料',
              subtitle: widget.auth.isSignedIn
                  ? '${widget.auth.user?.username ?? ''} · ${widget.auth.user?.email ?? ''}'
                  : '当前为游客，登录后可管理个人资料',
              trailingLabel: widget.auth.isSignedIn ? '查看 / 编辑' : '邮箱登录',
              onTap: _openAccount,
            ),
            const SizedBox(height: 10),
            _menuCard(
              icon: Icons.cloud_sync_outlined,
              iconColor: _forest,
              title: '账号云端进度',
              subtitle: '手动上传或恢复 SQLite 计划快照',
              trailingLabel: widget.auth.isSignedIn ? '进入同步' : '登录后可用',
              onTap: _openCloudProgress,
            ),
            const SizedBox(height: 10),
            _menuCard(
              icon: Icons.collections_bookmark_outlined,
              iconColor: _forest,
              title: '我的收藏',
              subtitle: '蝴蝶图鉴与未来主题系列',
              trailingLabel: '查看图鉴',
              onTap: _openCollectionPreview,
            ),
            const SizedBox(height: 10),
            _menuCard(
              icon: Icons.emoji_events_outlined,
              iconColor: const Color(0xFFC29442),
              title: '成就与徽章',
              subtitle: '记录成长里程碑',
              trailingLabel: '后续接入',
              onTap: null,
            ),
            const SizedBox(height: 10),
            _menuCard(
              icon: Icons.settings_outlined,
              iconColor: _muted,
              title: '设置',
              subtitle: '本地备份、数据恢复与应用偏好',
              trailingLabel: '管理设置',
              onTap: _openSettings,
            ),
          ],
        ),
      ),
    );
  }

  Widget _profileCard() {
    final avatarUrl = widget.auth.api.absoluteAvatarUrl(widget.auth.user?.avatar);
    return Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF315C48), Color(0xFF527C63)],
          ),
          boxShadow: const [
            BoxShadow(
              color: Color(0x18315C48),
              blurRadius: 16,
              offset: Offset(0, 7),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.16),
                borderRadius: BorderRadius.circular(19),
                border: Border.all(color: Colors.white.withValues(alpha: 0.25)),
                image: avatarUrl == null ? null : DecorationImage(
                    image: NetworkImage(avatarUrl), fit: BoxFit.cover),
              ),
              child: avatarUrl == null ? const Icon(
                Icons.person_outline_rounded,
                size: 32,
                color: Colors.white,
              ) : null,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.auth.isSignedIn
                        ? widget.auth.user?.username ?? '我的成长档案'
                        : '我的成长档案',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    widget.auth.isSignedIn
                        ? widget.auth.user?.email ?? ''
                        : '游客模式 · 计划保存在本机',
                    style: const TextStyle(
                      color: Color(0xFFE1EBE3),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.white),
          ],
        ),
      );
  }

  Widget _sectionTitle(String title, String subtitle) => Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF26392E),
              fontSize: 17,
              fontWeight: FontWeight.w800,
            ),
          ),
          Flexible(
            child: Text(
              subtitle,
              textAlign: TextAlign.right,
              style: const TextStyle(color: _muted, fontSize: 11),
            ),
          ),
        ],
      );

  Widget _assetCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) => Container(
        padding: const EdgeInsets.fromLTRB(10, 13, 10, 13),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: _border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 21),
            const SizedBox(height: 9),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF26392E),
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 3),
            Text(title, style: const TextStyle(color: _muted, fontSize: 11)),
          ],
        ),
      );

  Widget _growthCard(int? exp) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFFF0ECF8),
          borderRadius: BorderRadius.circular(19),
          border: Border.all(color: const Color(0xFFE3DCF0)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: const Color(0xFF8974B5).withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Icon(Icons.auto_awesome_rounded,
                  color: Color(0xFF8974B5)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '成长等级',
                    style: TextStyle(
                      color: Color(0xFF3D3158),
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    '当前累计经验：${exp ?? '—'} EXP',
                    style: const TextStyle(
                      color: Color(0xFF625579),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 5),
                  const Text(
                    '等级与盲盒解锁规则将在成长系统阶段接入，当前不显示虚构等级。',
                    style: TextStyle(
                      color: Color(0xFF756A89),
                      fontSize: 11,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _menuCard({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required String trailingLabel,
    required VoidCallback? onTap,
  }) => Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(17),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color: _border),
            ),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: iconColor.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(icon, color: iconColor, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: Color(0xFF26392E),
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: const TextStyle(color: _muted, fontSize: 11),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  trailingLabel,
                  style: TextStyle(
                    color: onTap == null ? _muted : _forest,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(width: 4),
                Icon(Icons.chevron_right_rounded,
                    color: onTap == null ? const Color(0xFFC4CBC5) : _muted),
              ],
            ),
          ),
        ),
      );

  void _openCollectionPreview() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => CollectionPage(api: widget.api),
      ),
    );
  }

  void _openSettings() {
    Navigator.of(context)
        .push(
          MaterialPageRoute<void>(
            builder: (_) => SettingsPage(api: widget.api),
          ),
        )
        .then((_) {
          if (mounted) _load();
        });
  }
}
