import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'private_sync_vault.dart';

// Connect ONLY to the local backup export/restore code that your project
// already uses. Never replace this with ad-hoc SQL DELETE/INSERT statements.
typedef ExportBackupJson = Future<String> Function();
typedef RestoreBackupJson = Future<void> Function(String backupJson);

class ArchiveDataBridge {
  const ArchiveDataBridge({
    required this.exportJson,
    required this.restoreJson,
  });

  final ExportBackupJson exportJson;
  final RestoreBackupJson restoreJson;
}

class WebDavCredentials {
  const WebDavCredentials({required this.account, required this.appPassword});

  final String account;
  final String appPassword;
}

class ArchiveCredentialStore {
  ArchiveCredentialStore({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  final FlutterSecureStorage _storage;
  static const _accountKey = 'pbb.webdav.account';
  static const _passwordKey = 'pbb.webdav.appPassword';

  Future<WebDavCredentials?> read() async {
    final account = await _storage.read(key: _accountKey);
    final password = await _storage.read(key: _passwordKey);
    if (account == null || account.isEmpty ||
        password == null || password.isEmpty) {
      return null;
    }
    return WebDavCredentials(account: account, appPassword: password);
  }

  Future<void> save(WebDavCredentials credentials) async {
    await _storage.write(key: _accountKey, value: credentials.account);
    await _storage.write(key: _passwordKey, value: credentials.appPassword);
  }

  Future<void> clear() async {
    await _storage.delete(key: _accountKey);
    await _storage.delete(key: _passwordKey);
  }
}

class CloudArchiveInfo {
  const CloudArchiveInfo({required this.createdAt, required this.fileName});

  final DateTime createdAt;
  final String fileName;
}

class DownloadedArchive {
  const DownloadedArchive({required this.info, required this.backupJson});

  final CloudArchiveInfo info;
  final String backupJson;
}

class JianguoyunWebDav {
  JianguoyunWebDav({http.Client? client})
      : _client = client ?? http.Client(),
        _ownsClient = client == null;

  final http.Client _client;
  final bool _ownsClient;
  static final Uri _root = Uri.parse('https://dav.jianguoyun.com/dav/');
  // Keep separate PlanBlindBox accounts in independent DAV directories.
  // Never trust a remote filename or URL as a path component.
  Uri _accountFolder(int owner) => _root.resolve('PlanBlindBox/account_$owner/');

  Future<http.Response> _send(
    String method,
    Uri uri,
    WebDavCredentials credentials, {
    String? body,
    Map<String, String> headers = const {},
  }) async {
    final request = http.Request(method, uri);
    request.headers.addAll(headers);
    request.headers['Authorization'] =
        'Basic ${base64Encode(utf8.encode('${credentials.account}:${credentials.appPassword}'))}';
    if (body != null) {
      request.headers['Content-Type'] = 'application/json; charset=utf-8';
      request.body = body;
    }
    final response = await _client.send(request).timeout(
      const Duration(seconds: 30),
    );
    return http.Response.fromStream(response);
  }

  void _require(http.Response response, List<int> allowed, String action) {
    if (!allowed.contains(response.statusCode)) {
      throw StateError('$action失败：HTTP ${response.statusCode}');
    }
  }

  Future<void> testConnection(WebDavCredentials credentials) async {
    final response = await _send(
      'PROPFIND', _root, credentials, headers: const {'Depth': '0'},
    );
    _require(response, [207], 'WebDAV 连接测试');
  }

  Future<void> _ensureFolder(WebDavCredentials credentials, Uri folder) async {
    final base = await _send('MKCOL', _root.resolve('PlanBlindBox/'), credentials);
    _require(base, [201, 405], '创建 PlanBlindBox 目录');
    final response = await _send('MKCOL', folder, credentials);
    // 405 means the collection already exists in common WebDAV implementations.
    _require(response, [201, 405], '创建存档目录');
  }

  Future<CloudArchiveInfo> upload(
    WebDavCredentials credentials,
    String backupJson,
    String backupPassword,
  ) async {
    final payload = jsonDecode(backupJson); // Validate before any network write.
    if (payload is! Map<String, dynamic> ||
        payload['format'] != 'planblindbox-local-backup' ||
        payload['backupUserId'] is! int) {
      throw const FormatException('备份必须声明当前账号，禁止上传不明来源的数据');
    }
    final owner = payload['backupUserId'] as int;
    final folder = _accountFolder(owner);
    final latest = folder.resolve('latest.json');
    final created = DateTime.now().toUtc();
    final random = Random.secure().nextInt(0x7fffffff);
    final timestamp = created.toIso8601String()
        .replaceAll(':', '').replaceAll('.', '').replaceAll('-', '');
    final fileName = 'pbb_${timestamp}_$random.json';
    final encrypted = await WebDavArchiveCipher.encrypt(
        backupJson, backupPassword, owner);
    final envelope = jsonEncode({
      'app': 'PlanBlindBox',
      'archiveVersion': 2,
      'owner': owner,
      'createdAt': created.toIso8601String(),
      'encrypted': encrypted,
    });
    final digest = sha256.convert(utf8.encode(envelope)).toString();

    await _ensureFolder(credentials, folder);
    final target = folder.resolve(fileName);
    final uploaded = await _send('PUT', target, credentials, body: envelope);
    _require(uploaded, [200, 201, 204], '上传存档');

    // Verify file contents before moving the latest pointer.
    final verify = await _send('GET', target, credentials);
    _require(verify, [200], '校验云端存档');
    if (sha256.convert(verify.bodyBytes).toString() != digest) {
      throw StateError('上传后校验失败：云端存档内容不一致');
    }

    // Update pointer last, so a failed upload cannot overwrite the previous one.
    final pointer = jsonEncode({
      'fileName': fileName,
      'createdAt': created.toIso8601String(),
      'sha256': digest,
    });
    final updated = await _send('PUT', latest, credentials, body: pointer);
    _require(updated, [200, 201, 204], '更新最新存档索引');

    return CloudArchiveInfo(createdAt: created, fileName: fileName);
  }

  Future<DownloadedArchive> downloadLatest(
    WebDavCredentials credentials, int owner, String backupPassword,
    {bool allowLegacyPlaintext = false}
  ) async {
    Uri folder = _accountFolder(owner);
    var pointerResponse = await _send('GET', folder.resolve('latest.json'), credentials);
    if (pointerResponse.statusCode == 404) {
      // Read old single-folder archives for migration, but only AFTER verifying
      // the backupUserId inside the downloaded envelope matches this account.
      folder = _root.resolve('PlanBlindBox/');
      pointerResponse = await _send('GET', folder.resolve('latest.json'), credentials);
    }
    if (pointerResponse.statusCode == 404) {
      throw StateError('云端暂无存档');
    }
    _require(pointerResponse, [200], '读取最新存档索引');
    final pointer = jsonDecode(pointerResponse.body);
    if (pointer is! Map<String, dynamic>) {
      throw const FormatException('云端索引格式错误');
    }
    final fileName = pointer['fileName'];
    final digest = pointer['sha256'];
    if (fileName is! String ||
        !RegExp(r'^pbb_[A-Za-z0-9_]+\.json$').hasMatch(fileName) ||
        digest is! String ||
        !RegExp(r'^[a-f0-9]{64}$').hasMatch(digest)) {
      throw const FormatException('云端索引存在非法文件名或摘要');
    }

    final response = await _send('GET', folder.resolve(fileName), credentials);
    _require(response, [200], '下载存档');
    if (sha256.convert(response.bodyBytes).toString() != digest) {
      throw const FormatException('存档 SHA-256 校验失败，未执行恢复');
    }
    final envelope = jsonDecode(utf8.decode(response.bodyBytes));
    if (envelope is! Map<String, dynamic> ||
        envelope['app'] != 'PlanBlindBox' ||
        envelope['createdAt'] is! String) {
      throw const FormatException('存档格式或版本不支持，未执行恢复');
    }
    final createdAt = DateTime.tryParse(envelope['createdAt'] as String);
    if (createdAt == null) throw const FormatException('存档时间无效');
    late final String plaintext;
    if (envelope['archiveVersion'] == 2) {
      if (envelope['owner'] != owner || envelope['encrypted'] is! Map) {
        throw const FormatException('云端存档属于其他账号，已拒绝恢复');
      }
      plaintext = await WebDavArchiveCipher.decrypt(
          Map<String, dynamic>.from(envelope['encrypted'] as Map),
          backupPassword, owner);
    } else if (envelope['archiveVersion'] == 1) {
      // Old unencrypted snapshots require a second, explicit user opt-in.
      if (!allowLegacyPlaintext) throw const LegacyPlaintextArchiveException();
      plaintext = jsonEncode(envelope['payload']);
    } else {
      throw const FormatException('存档版本不支持，未执行恢复');
    }
    final payload = jsonDecode(plaintext);
    if (payload is! Map<String, dynamic> || payload['backupUserId'] != owner ||
        payload['format'] != 'planblindbox-local-backup') {
      throw const FormatException('云端存档属于其他账号，已拒绝恢复');
    }
    return DownloadedArchive(
      info: CloudArchiveInfo(createdAt: createdAt, fileName: fileName),
      backupJson: plaintext,
    );
  }

  void dispose() {
    if (_ownsClient) _client.close();
  }
}

class LegacyPlaintextArchiveException implements Exception {
  const LegacyPlaintextArchiveException();
  @override
  String toString() => '检测到未加密的旧版备份，需要明确确认后恢复';
}

class CloudArchiveController {
  CloudArchiveController({
    required this.bridge,
    required this.currentOwner,
    ArchiveCredentialStore? store,
    JianguoyunWebDav? webDav,
  })  : store = store ?? ArchiveCredentialStore(),
        webDav = webDav ?? JianguoyunWebDav();

  final ArchiveDataBridge bridge;
  final int Function() currentOwner;
  final ArchiveCredentialStore store;
  final JianguoyunWebDav webDav;

  Future<CloudArchiveInfo> upload(String backupPassword) async {
    final credentials = await store.read();
    if (credentials == null) throw StateError('请先配置坚果云');
    final data = await bridge.exportJson();
    final decoded = jsonDecode(data);
    if (decoded is! Map || decoded['backupUserId'] != currentOwner()) {
      throw StateError('账号在备份过程中已切换，上传已取消');
    }
    return webDav.upload(credentials, data, backupPassword);
  }

  Future<DownloadedArchive> downloadLatest(String backupPassword,
      {bool allowLegacyPlaintext = false}) async {
    final credentials = await store.read();
    if (credentials == null) throw StateError('请先配置坚果云');
    return webDav.downloadLatest(credentials, currentOwner(), backupPassword,
        allowLegacyPlaintext: allowLegacyPlaintext);
  }

  // Restore MUST be atomic in the existing local backup implementation.
  // This method does not write directly to SQLite or bypass its validation.
  Future<void> restore(DownloadedArchive archive) async {
    await bridge.restoreJson(archive.backupJson);
  }

  void dispose() => webDav.dispose();
}
