package com.planblindbox.mod.api;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.Arrays;

@Configuration
public class CorsConfig implements WebMvcConfigurer {
    @Value("${mod.allowed-origins:http://localhost:3000}") private String origins;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // V2 auth and sync endpoints must be callable by Flutter Web as well
        // as the existing V1 public APIs. Internal OPAQUE sidecar routes are
        // not exposed through this Java HTTP API.
        registry.addMapping("/api/**")
            .allowedOrigins(Arrays.stream(origins.split(","))
                .map(String::trim)
                .filter(value -> !value.isEmpty())
                .toArray(String[]::new))
            .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
            .allowedHeaders("Authorization", "Content-Type")
            .maxAge(3600);
    }
}
