# Generated code do not commit.
file(TO_CMAKE_PATH "E:\\work\\tool\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "E:\\CODE\\code\\plan_blind_box_flutter" PROJECT_DIR)

set(FLUTTER_VERSION "0.1.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=E:\\work\\tool\\flutter"
  "PROJECT_DIR=E:\\CODE\\code\\plan_blind_box_flutter"
  "FLUTTER_ROOT=E:\\work\\tool\\flutter"
  "FLUTTER_EPHEMERAL_DIR=E:\\CODE\\code\\plan_blind_box_flutter\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=E:\\CODE\\code\\plan_blind_box_flutter"
  "FLUTTER_TARGET=E:\\CODE\\code\\plan_blind_box_flutter\\lib\\main.dart"
  "DART_DEFINES=QVBJX0JBU0VfVVJMPWh0dHA6Ly9sb2NhbGhvc3Q6ODA4MA==,VVNFUl9JRD0x,RkxVVFRFUl9CVUlMRF9OQU1FPTAuMS4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuNw==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049YWJhZjljNTIzNw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ZGViMjg3NDgxZQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy41"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=E:\\CODE\\code\\plan_blind_box_flutter\\.dart_tool\\package_config.json"
)
