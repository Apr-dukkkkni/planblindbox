package com.planblindbox.mod.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.planblindbox.mod.domain.BadRequest;
import org.springframework.http.HttpStatus;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

@Service
public class ModCatalogService {
    private final JdbcTemplate jdbc;
    private final ManifestValidator validator;
    private static final Pattern MOD_ID = Pattern.compile("^[a-z][a-z0-9]*(\\.[a-z][a-z0-9-]*)+$");
    private static final Pattern VERSION = Pattern.compile("^\\d+\\.\\d+\\.\\d+$");
    public ModCatalogService(JdbcTemplate jdbc, ManifestValidator validator) {
        this.jdbc=jdbc; this.validator=validator;
    }
    private void checkId(String id) {
        if (id == null || id.length()>100 || !MOD_ID.matcher(id).matches()) throw new BadRequest("Mod ID 格式错误");
    }
    private void checkVersion(String version) {
        if (version == null || version.length()>32 || !VERSION.matcher(version).matches()) throw new BadRequest("版本号格式错误");
    }
    private int compare(String a,String b) {
        String[] x=a.split("\\."), y=b.split("\\.");
        for(int i=0;i<3;i++) {
            int c = new java.math.BigInteger(x[i]).compareTo(new java.math.BigInteger(y[i]));
            if(c!=0) return c;
        }
        return 0;
    }

    public List<Map<String,Object>> list(String search,int page,int size) {
        if(page<0 || page>10000 || size<1 || size>50) throw new BadRequest("page 或 size 不合法");
        String q=search==null?"":search.trim();
        if(q.length()>100) throw new BadRequest("搜索词太长");
        return jdbc.queryForList("""
             SELECT p.mod_id AS id, p.name, p.description, p.latest_version AS latestVersion,
               (SELECT COUNT(*) FROM mod_download_events e WHERE e.mod_id=p.mod_id) AS downloads
             FROM mod_packages p WHERE p.enabled=TRUE
               AND (LOCATE(LOWER(?), LOWER(p.mod_id)) > 0 OR LOCATE(LOWER(?), LOWER(p.name)) > 0)
             ORDER BY p.updated_at DESC, p.mod_id ASC LIMIT ? OFFSET ?
             """, q, q, size,page*size);
    }
    public Map<String,Object> detail(String id) {
        checkId(id);
        List<Map<String,Object>> rows=jdbc.queryForList("""
          SELECT p.mod_id AS id,p.name,p.description,p.latest_version AS latestVersion,
           (SELECT COUNT(*) FROM mod_download_events e WHERE e.mod_id=p.mod_id) AS downloads
          FROM mod_packages p WHERE p.mod_id=? AND p.enabled=TRUE
          """,id);
        if(rows.isEmpty()) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Mod 不存在或已下架");
        Map<String,Object> result = new java.util.LinkedHashMap<>(rows.get(0));
        result.put("versions", jdbc.queryForList("SELECT version, created_at AS publishedAt FROM mod_versions WHERE mod_id=? ORDER BY id DESC",id));
        return result;
    }
    public String manifest(String id,String version) {
        checkId(id); checkVersion(version);
        List<String> list=jdbc.query("""
            SELECT v.manifest_json FROM mod_versions v JOIN mod_packages p ON p.mod_id=v.mod_id
            WHERE v.mod_id=? AND v.version=? AND p.enabled=TRUE
            """,(rs,i)->rs.getString(1),id,version);
        if(list.isEmpty()) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Mod 版本不存在或已下架");
        return list.get(0);
    }

    @Transactional
    public Map<String,String> publish(String raw) {
        JsonNode m=validator.validate(raw);
        String id=m.get("id").asText(), version=m.get("version").asText();
        String name=m.get("name").asText(), desc=m.has("description")?m.get("description").asText():"";
        List<Map<String,Object>> found=jdbc.queryForList("SELECT latest_version,enabled FROM mod_packages WHERE mod_id=? FOR UPDATE",id);
        if(found.isEmpty()) {
            jdbc.update("INSERT INTO mod_packages(mod_id,name,description,latest_version,enabled) VALUES (?,?,?,?,TRUE)",id,name,desc,version);
        } else {
            String current=(String)found.get(0).get("latest_version");
            if(compare(version,current)<=0) throw new ResponseStatusException(HttpStatus.CONFLICT,"发布版本必须高于已有版本");
            jdbc.update("UPDATE mod_packages SET name=?,description=?,latest_version=?,updated_at=CURRENT_TIMESTAMP WHERE mod_id=?",name,desc,version,id);
        }
        jdbc.update("INSERT INTO mod_versions(mod_id,version,manifest_json) VALUES (?,?,?)",id,version,raw);
        return Map.of("id",id,"version",version,"status","PUBLISHED");
    }

    @Transactional
    public Map<String,Object> download(String id,String version,String requestId) {
        checkId(id); checkVersion(version);
        UUID uuid;
        try {uuid=UUID.fromString(requestId);}catch(Exception e){throw new BadRequest("requestId 必须是 UUID");}
        String normalized=uuid.toString();
        String json=manifest(id,version);
        // 并发安全幂等：只依赖数据库 request_id 唯一约束来仲裁首次请求。
        // 不先 SELECT 再 INSERT，否则并发请求可能同时判定「尚未下载」。
        KeyHolder keyHolder = new GeneratedKeyHolder();
        try {
            jdbc.update(connection -> {
                var statement = connection.prepareStatement(
                    "INSERT INTO mod_download_events(request_id,mod_id,version) VALUES (?,?,?)",
                    new String[] {"id"});
                statement.setString(1, normalized);
                statement.setString(2, id);
                statement.setString(3, version);
                return statement;
            }, keyHolder);
        } catch (DuplicateKeyException duplicate) {
            // FOR UPDATE 是当前读，避免 MySQL REPEATABLE READ 的旧快照
            // 无法看到另一个事务刚刚提交的请求记录。
            List<Map<String,Object>> existing = jdbc.queryForList(
                "SELECT mod_id,version FROM mod_download_events WHERE request_id=? FOR UPDATE",
                normalized);
            if (existing.isEmpty()) throw duplicate;
            if (!id.equals(existing.get(0).get("mod_id")) ||
                !version.equals(existing.get(0).get("version"))) {
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "requestId 已被其他 Mod 下载请求使用");
            }
            return Map.of("manifest", json, "requestId", normalized, "counted", false);
        }
        Number downloadEventId = keyHolder.getKey();
        if (downloadEventId == null) throw new IllegalStateException("缺少下载事件主键");
        jdbc.update(
            "INSERT INTO mod_download_outbox(download_event_id,mod_id) VALUES (?,?)",
            downloadEventId.longValue(), id);
        return Map.of("manifest",json,"requestId",normalized,"counted",true);
    }
    @Transactional
    public Map<String,Object> changeVisibility(String id,boolean enabled) {
        checkId(id);
        int count=jdbc.update("UPDATE mod_packages SET enabled=?, updated_at=CURRENT_TIMESTAMP WHERE mod_id=?",enabled,id);
        if(count==0)throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Mod 不存在");
        return Map.of("id",id,"enabled",enabled);
    }
}
