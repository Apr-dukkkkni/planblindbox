package com.planblindbox.service;

import com.planblindbox.dto.response.DailySignInResponse;

public interface DailySignInService {

    DailySignInResponse signIn(Long userId);
}