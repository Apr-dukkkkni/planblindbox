package com.planblindbox.controller;

import com.planblindbox.common.Result;
import com.planblindbox.dto.response.DailySignInResponse;
import com.planblindbox.service.DailySignInService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/daily-sign-in")
@RequiredArgsConstructor
public class DailySignInController {

    private final DailySignInService dailySignInService;

    @PostMapping
    public Result<DailySignInResponse> signIn(
            @RequestParam Long userId) {
        return Result.success(
                dailySignInService.signIn(userId));
    }
}